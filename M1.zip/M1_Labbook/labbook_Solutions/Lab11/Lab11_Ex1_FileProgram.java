package capgemini.labbook.Lab11;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Lab11_Ex1_FileProgram {
	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream = new FileInputStream(
					new File("C:\\Capgemini\\File\\Lab11_Ex1_SourceFiles.txt"));
			FileOutputStream fileOutputStream = new FileOutputStream(
					new File("C:\\Capgemini\\File\\Lab11_Ex1_TargetFiles.txt"));
			ExecutorService serv = Executors.newSingleThreadExecutor();
			Future<String> future = serv.submit(new Lab11_Ex1_CopyDataThread(fileInputStream, fileOutputStream));
			System.out.println(future.get());
			serv.shutdown();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

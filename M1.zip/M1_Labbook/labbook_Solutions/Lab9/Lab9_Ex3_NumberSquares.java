







package capgemini.labbook.Lab9;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Lab9_Ex3_NumberSquares {
	public static void main(String[] args) {
		Integer[] arr = { 1, 8, 5, 2, 10 };
		System.out.println(getSquares(arr));
	}

	private static Map<Integer, Integer> getSquares(Integer[] arr) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		Iterator<Map.Entry<Integer, Integer>> itrerator = map.entrySet()
				.iterator();
		for (int i = 0; i < arr.length; i++) {
			map.put(arr[i], arr[i] * arr[i]);
		}

		return map;
	}

}

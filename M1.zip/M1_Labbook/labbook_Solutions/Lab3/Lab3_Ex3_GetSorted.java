package capgemini.labbook.Lab3;

import java.util.Arrays;

public class Lab3_Ex3_GetSorted {

	public static void main(String[] args) {

		int arr[] = Lab3_Ex3_GetSorted.getSorted(new int[] { 12,25,124,562,8456,7852 });
		System.out.println(Arrays.toString(arr));
	}

	public static int[] getSorted(int[] array) {
		StringBuilder s;
		for (int i = 0; i < array.length; i++) {
			s = new StringBuilder(Integer.toString(array[i]));
			s.reverse();
			array[i] = Integer.parseInt(s.toString());
		}
		Arrays.sort(array);
		return array;

	}
}

package capgemini.labbook.Lab3;

import java.util.Arrays;

public class Lab3_Ex1_GetSecondSmallest {

	public static void main(String[] args) {
		int SecondSmall = Lab3_Ex1_GetSecondSmallest.getSecondSmallest(new int[] { 1, 2, 5, 8, 4, 9 });
		System.out.println(SecondSmall);

	}

	public static int getSecondSmallest(int[] array) {
		Arrays.sort(array);
		return array[1];
	}

}

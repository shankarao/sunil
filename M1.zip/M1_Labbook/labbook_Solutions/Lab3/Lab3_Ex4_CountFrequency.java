package capgemini.labbook.Lab3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class Lab3_Ex4_CountFrequency {

	public static void main(String[] args) {

		Lab3_Ex4_CountFrequency.countFrequency(new char[] { 'a', 'a', 'a', 'z', 'e', 'y', 'z', 'r' });
	}

	public static void countFrequency(char ch[]) {
		ArrayList<Character> a1 = new ArrayList<Character>();
		for (int i = 0; i < ch.length; i++) {
			a1.add(ch[i]);
		}
		TreeSet<Character> set = new TreeSet<Character>(a1);
		System.out.println(a1);
		for (Character c : set) {
			System.out.println(c + ":" + Collections.frequency(a1, c) + "  ");
		}
	}
}

package com.capgemini.dao;

import com.capgemini.bean.Author;
import com.capgemini.bean.Book;

public interface BookDao {
	public int insertToBook(Book book);
	public void insertToAuthor(Author author);
	public Book getBookDetails(String name);
	public void updatePrice(String name,int amount);
}

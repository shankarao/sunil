package capgemini.labbook;

public abstract class Item {
	protected int identification_Number;
	protected String title;
	protected int number_Of_Copies;

	public abstract int getIdentification_Number();

	public abstract String getTitle();

	public abstract int getNumber_Of_Copies();

	public abstract void setIdentification_Number(int identification_Nmuber);

	public abstract void setTitle(String title);

	public abstract void setNumber_Of_Copies(int number_Of_Copies);
}

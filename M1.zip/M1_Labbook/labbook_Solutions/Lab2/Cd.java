package capgemini.labbook;

public class Cd extends MediaItem {
	// field
	private String artist;
	private String genre;

	public Cd() {
		super();
		artist = null;
		genre = null;

	}

	public Cd(String artist, String genre) {
		super();
		this.artist = artist;
		this.genre = genre;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "Cd [artist=" + artist + ", genre=" + genre + ", runtime=" + runtime + ", identification_Number="
				+ identification_Number + ", title=" + title + ", number_Of_Copies=" + number_Of_Copies + "]";
	}

	public void setNumber_Of_Copies(int number_Of_Copies) {
		this.number_Of_Copies = number_Of_Copies;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public int getRuntime() {
		return runtime;
	}

	@Override
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	@Override
	public int getIdentification_Number() {
		return identification_Number;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public int getNumber_Of_Copies() {
		return number_Of_Copies;
	}

	@Override
	public void setIdentification_Number(int identification_Nmuber) {
		this.identification_Number = identification_Nmuber;
	}

}

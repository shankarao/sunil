
package capgemini.labbook;

public class Vedio extends MediaItem {
	private String director;
	private String genre;
	private int yearRealeased;

	public Vedio() {
		director = null;
		genre = null;
		yearRealeased = 0;
	}

	@Override
	public int getRuntime() {
		return runtime;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYearRealeased() {
		return yearRealeased;
	}

	public void setYearRealeased(int yearRealeased) {
		this.yearRealeased = yearRealeased;
	}

	public Vedio(String director, String genre, int yearRealeased) {
		super();
		this.director = director;
		this.genre = genre;
		this.yearRealeased = yearRealeased;
	}

	@Override
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}

	@Override
	public String toString() {
		return "Vedio [director=" + director + ", genre=" + genre + ", yearRealeased=" + yearRealeased + ", runtime="
				+ runtime + ", identification_Number=" + identification_Number + ", title=" + title
				+ ", number_Of_Copies=" + number_Of_Copies + "]";
	}

	@Override
	public int getIdentification_Number() {
		return identification_Number;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public int getNumber_Of_Copies() {
		return number_Of_Copies;
	}

	@Override
	public void setIdentification_Number(int identification_Nmuber) {
		this.identification_Number = identification_Nmuber;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public void setNumber_Of_Copies(int number_Of_Copies) {
		this.number_Of_Copies = number_Of_Copies;
	}

}

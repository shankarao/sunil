package capgemini.labbook.Lab5;

import java.util.Scanner;

public class Lab5_Ex4_ValidateName {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first name");
		String first = sc.nextLine();
		System.out.println("enter the second name");
		String second = sc.nextLine();

		try {
			if (first.isEmpty())
				throw new NameException("first name can't be blank");
			if (second.isEmpty())
				throw new NameException("second name can't be blank");
			System.out.println(first + " " + second);
		} catch (NameException e) {

		} finally {
			sc.close();
		}

	}

}

class NameException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6666936214308479011L;

	public NameException(String string) {
		System.err.println(string);
	}
}
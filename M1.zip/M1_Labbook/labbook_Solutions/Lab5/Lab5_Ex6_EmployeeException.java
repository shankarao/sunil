package capgemini.labbook.Lab5;

public class Lab5_Ex6_EmployeeException {

	int empid;
	String name;
	float salary;

	public Lab5_Ex6_EmployeeException() {
		empid = 0;
		name = null;
		salary = 0.0f;
	}

	public Lab5_Ex6_EmployeeException(int empid, String name, float salary) {
		this.empid = empid;
		this.name = name;
		try {
			if (salary < 3000) {
				throw new EmployeeException("empid :" + this.empid+" \t" + "salary cannot be less than 3000" + "\t" + this.name);
			}
		} catch (Exception e) {
		}
		this.salary = salary;
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Lab5_Ex6_EmployeeException emp1 = new Lab5_Ex6_EmployeeException(100,"arkay",200);
		/*Lab5_Ex6_EmployeeException emp2 = new Lab5_Ex6_EmployeeException(101,"veeru",99999);
		Lab5_Ex6_EmployeeException emp3 = new Lab5_Ex6_EmployeeException(102,"sivinay",54446);*/
	}
}


@SuppressWarnings("serial")
class EmployeeException extends Exception {
	public EmployeeException(String s) {
		System.out.println(s);

	}
}

package capgemini.labbook.Lab13;

import java.util.function.Function;

public class Lab13_Ex5_MethodReference {
	public static int factorial(int n){
		if(n==1||n==0)
			return 1;
		else
			return n*factorial(n-1);
	}
	
	public static void main(String[] args) {
		Function<Integer,Integer> func = Lab13_Ex5_MethodReference::factorial;
		System.out.println("Factorial of 5 is "+ func.apply(5));
	}

}

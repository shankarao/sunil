package capgemini.labbook.Lab13;

import java.util.function.BiConsumer;

public class Lab13_Ex1_Power {
	public static void main(String[] args) {
		BiConsumer<Integer, Integer> pow = (a, b) -> System.out
				.println((int) (Math.pow(a, b)));
		pow.accept(2, 8);
	}
}

package capgemini.labbook.Lab4;

public class Lab4_SumOfCubes {

	public static void main(String[] args) {
		System.out.println("sum:" + SumOfCubes(123));

	}

	public static int SumOfCubes(int n) {
		int n1, sum = 0;
		while (n > 0) {
			n1 = n % 10;
			sum = sum + (n1 * n1 * n1);
			n = n / 10;
		}
		return sum;
	}

}

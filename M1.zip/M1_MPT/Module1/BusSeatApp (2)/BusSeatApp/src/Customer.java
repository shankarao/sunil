public class Customer {

	private String customerName;
	private char gender;
	private int age;
	private int seatNo;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) throws SeatNoNotValidException {
		if (seatNo > 0 && seatNo <= 42)
			this.seatNo = seatNo;
		else {
			throw new SeatNoNotValidException("Invalid seat number");
			// fill the code
		}
	}

}

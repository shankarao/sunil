
public class SeatNoNotValidException extends Exception{
	SeatNoNotValidException(String st) {
		super(st);
	}
}

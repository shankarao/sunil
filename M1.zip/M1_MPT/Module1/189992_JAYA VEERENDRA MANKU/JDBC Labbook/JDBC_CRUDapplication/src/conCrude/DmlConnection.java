package connectionCrude;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DmlConnection {
private static Connection connection=null;
	
	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver);
			final String url="jdbc:oracle:thin:@10.138.151.14:1521:xe";
			connection=DriverManager.getConnection(url, "VEERU", "VEERU");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	public static void main(String[] args) {
		System.out.println(DmlConnection.getConnection());
	}
}

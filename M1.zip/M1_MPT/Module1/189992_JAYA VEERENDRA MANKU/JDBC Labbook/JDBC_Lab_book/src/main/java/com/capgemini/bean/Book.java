package com.capgemini.bean;

public class Book {
	private int isbn;
	private String title;
	private int authorId;
	private int price;
	public Book() {
		super();
	}
	public Book(int isbn, String title, int authorId, int price) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.authorId = authorId;
		this.price = price;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "isbn=" + isbn + ", title=" + title + ", authorId=" + authorId + ", price=" + price;
	}
	
}

package capgemini.labbook;

import java.util.Arrays;

public class Lab3_Ex3_GetSorted {
	public static void main(String[] args) {
		int arr[] = Lab3_Ex3_GetSorted.getSorted(new int[] {32, 332, 1166, 99, 70329});
		System.out.println(Arrays.toString(arr));
	}

	private static int[] getSorted(int[] array) {
		StringBuilder s;
		for(int i = 0;i < array.length; i++){
			s = new StringBuilder(Integer.toString(array[i]));
			s.reverse();
			array[i] = Integer.parseInt(s.toString());
		}
		Arrays.sort(array);
		return array;
	}

}

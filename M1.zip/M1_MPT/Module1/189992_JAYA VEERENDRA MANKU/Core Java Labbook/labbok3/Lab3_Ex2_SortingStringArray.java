package capgemini.labbook;

import java.util.Arrays;

public class Lab3_Ex2_SortingStringArray {
	public static void main(String[] args) {
		String s[] = Lab3_Ex2_SortingStringArray.sortStringArray(new String[] {
				"hi", "veeru", "what", "are", "doing" });
		for (String s1 : s) {
			System.out.print(s1 + " ");
		}
	}

	private static String[] sortStringArray(String[] string) {
		Arrays.sort(string);
		if (string.length % 2 == 0) {
			for (int i = 0; i < string.length; i++) {
				if (i < string.length / 2) {
					string[i] = string[i].toUpperCase();
				} else {
					string[i] = string[i].toLowerCase();
				}

			}
		} else {
			for (int i = 0; i < string.length; i++) {
				if (i < ((string.length) / 2) + 1) {
					string[i] = string[i].toUpperCase();
				} else {
					string[i] = string[i].toLowerCase();
				}

			}
		}
		return string;

	}

}

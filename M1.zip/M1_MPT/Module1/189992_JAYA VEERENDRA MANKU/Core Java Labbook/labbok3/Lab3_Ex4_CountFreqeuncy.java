package capgemini.labbook;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class Lab3_Ex4_CountFreqeuncy {
	public static void main(String[] args) {
		Lab3_Ex4_CountFreqeuncy.countfrequency(new char[] {'a' ,'b','v','z','a','d','r','y'});
	}

	private static void countfrequency(char[] cf) {
		ArrayList<Character> al = new ArrayList<Character>();
		for(int i = 0;i < cf.length; i++){
			al.add(cf[i]);
		}
		TreeSet<Character> st = new TreeSet<Character>(al);
		System.out.println(al);
		for(Character c : st){
			System.out.println(c + " : " + Collections.frequency(al,c) + " ");
			
		}
		
		
	}

}

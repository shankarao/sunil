package capgemini.labbook;

import java.util.Arrays;

public class Lab3_Ex1_GetSecondSmallest {
	public static void main(String[] args) {
		int second_smallest = Lab3_Ex1_GetSecondSmallest.getSecondsmallest(new int[] { 1, 3, 4, 9, 8, 2});
		System.out.println(second_smallest);
	}

	private static int getSecondsmallest(int[] array) {
		Arrays.sort(array);
		return array[1];
	}

}

package capgemini.labbook_lab14;

import java.util.Scanner;

public class Main {
	public static void main(String args[])
	{ 
		int a;
		CustomerDetails ad=new CustomerDetails();
		Scanner sc=new Scanner(System.in);
		
		
		do
		{
			 System.out.println("Specify your choice:");
			 a =sc.nextInt();
			switch(a)
			{
			case 1:
				ad.Add();
				break;
			case 2:
				ad.Retrieve();
				break;
			case 3:
				System.out.println(" Exit:");
				break;
			}
			
		}
		while(a!=3);
		sc.close();
	}

}

package capgemini.labbook_lab14;

public abstract class Medical {
	public abstract  void storeInService();

}

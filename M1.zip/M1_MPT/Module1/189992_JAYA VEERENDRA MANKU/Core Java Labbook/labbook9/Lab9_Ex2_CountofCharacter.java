package capgemini.labbook;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Lab9_Ex2_CountofCharacter {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String str = s.next();
		Map<Character, Integer> map = countCharacter(str);
		Iterator<Character> iterator = map.keySet().iterator();
		while (iterator.hasNext()) {
			char key = iterator.next();
			System.out.println(key + "=" + map.get(key));
		}
	}
	private static Map<Character, Integer> countCharacter(String str) {
		HashMap<Character, Integer> hash = new HashMap<Character, Integer>();
		char[] ch = str.toCharArray();
		int count = 1;
		Arrays.sort(ch);
		for (int i = 0; i < ch.length - 1; i++) {
			if (ch[i] == ch[i + 1]) {
				count++;
			} else {
				hash.put(ch[i], count);
				count = 1;
			}
		}
		hash.put(ch[ch.length - 1], count);
		return hash;
	}
}

package capgemini.labbook;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Lab9_Ex1_MapSortedOrder {
	public static void main(String[] args) {
		HashMap<Integer, Integer> hashmap = new HashMap<Integer, Integer>();
		hashmap.put(1, 10);
		hashmap.put(2, 5);
		hashmap.put(8, 9);
		hashmap.put(3, 4);
		hashmap.put(9, 2);
		List list = getValues(hashmap);
		System.out.println(hashmap);
	}

	private static List getValues(HashMap hm) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < hm.size(); i++) {
			list.add(i);
		}
		Collections.sort(list);
		return list;
	}
}

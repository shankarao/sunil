package capgemini.labbook;

import java.util.Scanner;
import java.util.stream.Stream;

public class Lab13_Ex3_ValidateUserpass {

	    public static void main(String[] args) {
	        
	        Scanner scan = new Scanner(System.in);
	        System.out.println("Enter the User Name :");
	        Stream<String> stream = Stream.of(scan.next());
	        System.out.println("Enter the Password:");
	        Stream<String> stream2 = Stream.of(scan.next());
	        boolean resultPass = stream2.anyMatch( (str2) -> { if(str2.equals("veru12345")){return true;} else {return false;}});
	        boolean result = stream.anyMatch((str1) -> {if(str1.equals("vinay")){ return resultPass;} else{return false;} });
	        if(result){
	            System.out.println("True");
	        }
	        else {
	            System.out.println("False");
	        }
	    }
	}
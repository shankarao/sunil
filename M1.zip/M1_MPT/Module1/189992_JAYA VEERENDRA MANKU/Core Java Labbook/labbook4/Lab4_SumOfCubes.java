package capgemini.labbook;

public class Lab4_SumOfCubes {
	public static void main(String[] args) {
		System.out.println("Sum = " + SumOfCubes(12325));
	}

	public static int SumOfCubes(int a) {

		int sum = 0, n;
		while (a != 0) {
			n = a % 10;
			sum = sum + (n * n * n);
			a = a / 10;

		}

		return sum;

	}

}

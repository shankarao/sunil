package capgemini.labbook;

public class Lab1_Ex1_CalculateSum {
	public static int calculateSum(int n){
		int sum = 0;
		for(int index=1;index<=n;index++){
			if(index%3 == 0 || index%5 == 0)
				sum = sum + index;
		}
		return sum;
	}
	public static void main(String[] args) {
		System.out.println(calculateSum(10));
	}

}

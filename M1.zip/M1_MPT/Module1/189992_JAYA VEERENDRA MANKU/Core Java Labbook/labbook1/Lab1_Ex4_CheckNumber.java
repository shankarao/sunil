package capgemini.labbook;

public class Lab1_Ex4_CheckNumber {
	public static void main(String[] args) {
		if(checkNumber(31))
			System.out.println("Power of 2");
		else
			System.out.println("Not a power of 2");
	}
	public static boolean checkNumber(int n){
		double d = (Math.log(n) / Math.log(2));
		int i = (int) d ;
		if(d == i)
			return true;
		else
			return false;
	}

}

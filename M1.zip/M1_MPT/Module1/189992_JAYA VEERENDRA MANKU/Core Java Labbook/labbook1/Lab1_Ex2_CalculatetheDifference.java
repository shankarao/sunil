package capgemini.labbook;

public class Lab1_Ex2_CalculatetheDifference {
	public static void main(String[] args) {
		System.out.println(calculatedifference(2));
	}
	public static int calculatedifference(int n){
		int sum1 = 0, sum2 = 0, sum;
		for(int index=1;index<=n;index++){
			sum1 = sum1 + (index*index);
			sum2 = sum2 + index;
		}
			sum = sum1 - (sum2*sum2);
			return sum;
		}
		
	}
	


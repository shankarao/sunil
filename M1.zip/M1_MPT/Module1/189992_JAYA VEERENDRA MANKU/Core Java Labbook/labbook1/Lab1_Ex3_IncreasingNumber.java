package capgemini.labbook;

import java.util.Arrays;

public class Lab1_Ex3_IncreasingNumber {
	public static void main(String[] args) {
		boolean bool = checkNumber(134468);
		if (bool == true)
			System.out.println("Increasing Number");
		else
			System.out.println("Not an Increasing number");
	}

	public static boolean checkNumber(int n) {
		String num = Integer.toString(n);
		char array[] = new char[num.length()];
		char brr[] = new char[num.length()];
		for (int i = 1; i < num.length(); i++) {
			char s = num.charAt(i);
			array[i] = s;
			brr[i] = s;
		}
		Arrays.sort(array);
		if (Arrays.equals(array, brr))
			return true;
		else
			return false;

	}

}

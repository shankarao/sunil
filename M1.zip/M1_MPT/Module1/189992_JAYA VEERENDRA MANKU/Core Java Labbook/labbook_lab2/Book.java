package capgemini.labbook_lab2;

public class Book extends WrittenItem {
	@Override
	public String getAuthor() {
		return author;
	}

	@Override
	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public int getIdentification_number() {
		return identification_number;
	}

	public void setIdentification_number(int identification_number) {
		this.identification_number = identification_number;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String titile) {
		this.title = titile;
	}

	@Override
	public int getNumber_of_copies() {
		return number_of_copies;
	}

	@Override
	public void setNumber_of_copies(int number_of_copies) {
		this.number_of_copies = number_of_copies;
	}

	@Override
	public String toString() {
		return "Author : " + getAuthor() + "\nIdentification No.. : "
				+ getIdentification_number() + "\nTitle : " + getTitle()
				+ "\nNo.of copies : " + getNumber_of_copies();
	}

}

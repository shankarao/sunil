package capgemini.labbook_lab2;

public abstract class Item {
	protected int identification_number;
	protected String title;
	protected int number_of_copies;

	public abstract int getIdentification_number();

	public abstract void setIdentification_number(int identification_number);

	public abstract String getTitle();

	public abstract void setTitle(String title);

	public abstract int getNumber_of_copies();

	public abstract void setNumber_of_copies(int number_of_copies);
}

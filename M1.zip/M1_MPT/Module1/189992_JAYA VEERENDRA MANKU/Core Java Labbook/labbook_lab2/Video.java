package capgemini.labbook_lab2;

public class Video extends MediaItem {
	private String director;
	private String genre;
	private int yearReleased;

	public Video() {
		director = null;
		genre = null;
		yearReleased = 0;
	}

	public Video(String director, String genre, int yearReleased) {
		super();
		this.director = director;
		this.genre = genre;
		this.yearReleased = yearReleased;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getYearReleased() {
		return yearReleased;
	}

	public void setYearReleased(int yearReleased) {
		this.yearReleased = yearReleased;
	}

	public void setRuntime(int runtime) {
		this.runtime = runtime;
	
	}

	public int getRuntime() {

		return runtime;
	}
	
	
	@Override
	public String toString() {
		return "Video [director=" + director + ", genre=" + genre
				+ ", yearReleased=" + yearReleased + ", identification_number="
				+ identification_number + ", title=" + title
				+ ", number_of_copies=" + number_of_copies + "]";
	}

	@Override
	public int getIdentification_number() {
		return identification_number;
	}

	@Override
	public void setIdentification_number(int identification_number) {
		this.identification_number = identification_number;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public int getNumber_of_copies() {
		return number_of_copies;
	}

	@Override
	public void setNumber_of_copies(int number_of_copies) {
		this.number_of_copies = number_of_copies;
	}

}

package capgemini.labbook_lab2;

public class Lab2_Library {
	public static void main(String[] args) {
		Cd cd1 = new Cd();
		cd1.setIdentification_number(101);
		cd1.setNumber_of_copies(100);
		cd1.setRuntime(5);
		cd1.setTitle("Friends");

		Video v1 = new Video();
		v1.setIdentification_number(103);
		v1.setNumber_of_copies(300);
		v1.setRuntime(4);
		v1.setTitle("Come Here");

		Book b1 = new Book();
		b1.setAuthor("Arundhati");
		b1.setIdentification_number(104);
		b1.setNumber_of_copies(500);
		b1.setTitle("The Last Breadth");

		Journal j1 = new Journal();
		j1.setIdentification_number(105);
		j1.setNumber_of_copies(600);
		j1.setTitle("Full stack");

		System.out.println("CD Specifications : \n\n" + cd1);
		System.out.println("Video Specifications : \n\n" + v1);
		System.out.println("Book Specifications : \n\n" + b1);
		System.out.println("Journal Specifications : \n\n" + j1);
	}

}

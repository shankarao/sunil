package capgemini.labbook_lab2;

public class Journal extends WrittenItem {

	private int yearPublished;

	public Journal() {
		yearPublished = 0;
	}

	public Journal(int yearPublished) {
		setYearPublished(yearPublished);
	}

	@Override
	public String toString() {
		return "Journal [yearPublished=" + yearPublished + ", author=" + author
				+ ", identification_number=" + identification_number
				+ ", title=" + title + ", number_of_copies=" + number_of_copies
				+ "]";
	}

	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}

	@Override
	public int getIdentification_number() {

		return identification_number;
	}

	public void setIdentification_number(int identification_number) {
		this.identification_number = identification_number;

	}

	@Override
	public int getNumber_of_copies() {
		return number_of_copies;
	}

	public void setNumber_of_copies(int number_of_copies) {
		this.number_of_copies = number_of_copies;

	}

	@Override
	public String getTitle() {

		return title;
	}

	public void setTitle(String title) {
		this.title = title;

	}

	@Override
	public String getAuthor() {

		return author;
	}

	@Override
	public void setAuthor(String author) {
		this.author = author;

	}

}

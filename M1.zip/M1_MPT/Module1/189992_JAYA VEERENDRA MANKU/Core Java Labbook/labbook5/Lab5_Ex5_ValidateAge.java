package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex5_ValidateAge {
	
		public static void main(String[] args) {
			Scanner s = new Scanner(System.in);
			System.out.println("Enter Age : ");
			int age = s.nextInt();
			try {
				if (age < 15)
					throw new AgeException("your age is less than 15 years");
				System.out.println("Welcome..");
			} catch (AgeException e) {
			} finally {
				s.close();
			}
		}
	}

	class AgeException extends Exception {
		public AgeException(String s) {
			System.err.println(s);
		}
}

package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex6_EmpException {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Salary : ");
		int emp = s.nextInt();
		try {
			if (emp < 3000)
				throw new EmployeeException("your salary is less than 3000");
		} catch (EmployeeException e) {
		} finally {
			s.close();
		}
	}
}

class EmployeeException extends Exception {
	public EmployeeException(String s) {
		System.err.println(s);
	}

}

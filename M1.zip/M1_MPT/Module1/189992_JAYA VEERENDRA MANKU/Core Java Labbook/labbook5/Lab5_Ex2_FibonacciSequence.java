package capgemini.labbook;

public class Lab5_Ex2_FibonacciSequence {
	public static void main(String[] args) {
		int result = Lab5_Ex2_FibonacciSequence.findFibonacci(6);
		System.out.println(result);
		int result1 = Lab5_Ex2_FibonacciSequence.findFibonacciRecursion(5);
		System.out.println(result1);
	}

	private static int findFibonacci(int n) {
		int a = 1, b = 1, c = 0;
		for (int i = 0; i < n - 2; i++) {
			c = a + b;
			a = b;
			b = c;
		}
		return c;
	}

	private static int findFibonacciRecursion(int n) {
		if (n <= 1)
			return n;
		return findFibonacciRecursion(n - 1) + findFibonacciRecursion(n - 2);
	}

}

package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex4_ValidateName {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter First Name : ");
		String first = s.nextLine();
		System.out.println("Enter Last Name : ");
		String second = s.nextLine();
		try {
			if (first.isEmpty())
				throw new NameException("First Name Can't be Blank");
			if (second.isEmpty())
				throw new NameException("Second Name Can't be Blank");
			System.out.println(first + ":" + second);
		} catch (NameException e) {
		} finally {
			s.close();
		}
	}
}

class NameException extends Exception {
	public NameException(String string) {
		System.err.println(string);
	}
}

package capgemini.labbook;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex2_FileReadDisplay {
	public static void main(String[] args) throws IOException {
		File file = new File("C:\\capgemini\\Readme.txt");
		FileReader fileInput = new FileReader(file);
		LineNumberReader lineNumber = new LineNumberReader(fileInput);
		String s = lineNumber.readLine();
		while (s != null) {
			System.out.println(lineNumber.getLineNumber() + " " + s);
			s = lineNumber.readLine();
		}
		lineNumber.close();
	}
}

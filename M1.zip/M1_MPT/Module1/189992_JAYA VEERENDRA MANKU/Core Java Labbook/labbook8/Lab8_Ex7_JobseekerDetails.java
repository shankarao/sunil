package capgemini.labbook;

import java.util.Scanner;

public class Lab8_Ex7_JobseekerDetails {

	private static boolean validate(String username) {
		return username.matches("(.){8}_job");
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String username = new String();
		username = s.next();
		validate(username);
		if (validate(username)) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
	}

}

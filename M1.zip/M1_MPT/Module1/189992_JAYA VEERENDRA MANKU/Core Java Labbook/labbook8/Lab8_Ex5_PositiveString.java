package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;

public class Lab8_Ex5_PositiveString {
	 static boolean IsStringpositive(String str) {
		char[] ch = str.toCharArray();
		Arrays.sort(ch);
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] != str.charAt(i)) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter ");
		String str = s.next();
		if (IsStringpositive(str)) {
			System.out.println("String is Positive");
		} else {
			System.out.println("String is negative");
		}
	}
}

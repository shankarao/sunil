package capgemini.labbook;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab8_Ex6_CurrentSystemDate {
	public static void main(String[] args) {
		System.out.println("Enter the Date : ");
		Scanner s = new Scanner(System.in);
		String d = s.nextLine();
		LocalDate now = LocalDate.now();
		LocalDate dt = LocalDate.parse(d);
		Period dif = Period.between(dt, now);
		System.out.println("Difference is :\t" + dif.getDays()+ " Days \t" +  dif.getMonths() +" Months \t" + dif.getYears() + " Years");
		
		
	
}
}

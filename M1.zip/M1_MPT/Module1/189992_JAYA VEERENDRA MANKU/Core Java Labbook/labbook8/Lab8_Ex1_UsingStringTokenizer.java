package capgemini.labbook;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_UsingStringTokenizer {
	public static void main(String[] args) {
		int n,sum = 0;
		System.out.println("Enter ");
		Scanner s = new Scanner(System.in);
		String t = s.nextLine();
		StringTokenizer st = new StringTokenizer(t," ");
		while(st.hasMoreTokens()) {
			n = Integer.parseInt(st.nextToken());
			System.out.println(n + " ");
			sum = sum + n;
		}
		System.out.println();
		System.out.println("Sum : " + sum);
		s.close();
	}

}

package capgemini.labbook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lab8_Ex3_DisplayText {
	public static void main(String[] args) {
		File file = new File("C:\\capgemini\\Readme.txt");
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(file));
			int wordcount = 0, linecount = 0, charcount = 0;
			String currLine;
			while ((currLine = reader.readLine()) != null) {
				linecount++;
				String[] word = currLine.split(" ");
				wordcount += word.length;
				for (String words : word) {
					charcount += words.length();
				}
			}
			System.out.println("Number of Lines in Text : " + linecount);
			System.out.println("Number of Words in Text : " + wordcount);
			System.out.println("Number of sCharacters in Text : " + charcount);
			reader.close();
		} catch (FileNotFoundException e) {
			System.err.println("File Not Found");
		} catch (IOException e) {
			System.out.println("Don't do overaction");
		}

	}

}

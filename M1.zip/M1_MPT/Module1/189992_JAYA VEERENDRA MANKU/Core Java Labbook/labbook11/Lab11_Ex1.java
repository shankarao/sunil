package capgemini.labbook;

import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MusicPlayTask implements Runnable {
	public void run() {
		System.out.println("Music palying is executing");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Music play Exception");
		}
	}
}

class CopyTask implements Runnable {
	public void run() {
		System.out.println("Copy Task is Executing");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			System.out.println("Copy Task is resumed after sleep");
		}
	}

}

public class Lab11_Ex1 {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out
				.println("thread excutor & Executor service Demo\n 1.Executor\n 2.Executor Service \n enter your choice:  ");
		int ch = sc.nextInt();
		if (ch == 1) {
			Executor exc = Executors.newSingleThreadExecutor();
			exc.execute(new MusicPlayTask());
			exc.execute(new CopyTask());
		} else if (ch == 2) {
			ExecutorService excs1 = Executors.newSingleThreadExecutor();
			ExecutorService excs2 = Executors.newSingleThreadExecutor();
			excs1.execute(new MusicPlayTask());
			excs1.execute(new CopyTask());

		} else {
			System.out.println("Enter valid choice");

		}
		sc.close();
	}
}

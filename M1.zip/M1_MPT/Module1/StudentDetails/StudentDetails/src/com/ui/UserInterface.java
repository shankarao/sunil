package com.ui;

public class UserInterface {
	
	public static void main(String a[])
	{
		
	}

}

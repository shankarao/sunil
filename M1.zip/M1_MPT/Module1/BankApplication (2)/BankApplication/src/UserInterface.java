import java.util.Scanner;

public class UserInterface {

	public static void main(String a[]) {
		Scanner sc = new Scanner(System.in);
		int noOfEmployees = sc.nextInt();
		String employees[] = new String[noOfEmployees];
		for (int i = 0; i < noOfEmployees; i++) {
			employees[i] = sc.next();
		}
		int count = 0;
		StringBuilder stringBuilder = new StringBuilder();
		for (String s : employees) {
			String[] str = new String[2];
			str = s.split(",");
			str[1] = str[1].replaceAll(":", "");
			int num = Integer.parseInt(str[1]);
			if (num > 930) {
				count++;
				stringBuilder.append(str[0] + " ");
			}
		}
		System.out.println(count + " " + stringBuilder.toString() + "are late");

		sc.close();
	}

}
